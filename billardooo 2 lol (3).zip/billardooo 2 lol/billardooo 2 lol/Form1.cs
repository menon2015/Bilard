﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace billardooo_2_lol
{
    public partial class Form1 : Form
    {
        
        List<Ball> BallList = new List<Ball>();
        List<Hole> HoleList = new List<Hole>();

        public Form1()
        {
            InitializeComponent();

            Random r = new Random();
            for (int i = 1; i < 10; i++)

            {
                int red = r.Next(0, byte.MaxValue + 1);
                int green = r.Next(0, byte.MaxValue + 1);
                int blue = r.Next(0, byte.MaxValue + 1);
                SolidBrush brush = new System.Drawing.SolidBrush(Color.FromArgb(red, green, blue));
                BallList.Add(new Ball(pictureBox1.Height, pictureBox1.Width, (100 * i), (pictureBox1.Height / 2) - 15, 0, 0,brush));
            }
            HoleList.Add(new Hole(-40,-40));
            HoleList.Add(new Hole(-40, pictureBox1.Height-60));
            HoleList.Add(new Hole(pictureBox1.Width-60, -40));
            HoleList.Add(new Hole(pictureBox1.Width-60, pictureBox1.Height-60));
            HoleList.Add(new Hole((pictureBox1.Width/2)-50, -50));
            HoleList.Add(new Hole((pictureBox1.Width/2)-50, pictureBox1.Height-50));
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            
           
        }

        
            private List<int> Swapv(int vx1,int vy1,int vx2,int vy2)
        {


            return new List<int> { vx1, vy1, vx2, vy2 };
        }


        private bool Colide(Ball ball1,Ball ball2)
        {
            double distx=ball1.x-ball2.x;
            double disty= ball1.y - ball2.y;
            if (Math.Sqrt((distx*distx)+(disty*disty))<ball1.r)
            {
                return true;
            }
            return false;


        }


        private bool ColideHole(Ball ball, Hole hole
            )
        {
            double distx = ball.x - hole.x-50;
            double disty = ball.y - hole.y-50;
            if (Math.Sqrt((distx * distx) + (disty * disty)) < hole.r - ball.r*1.5)
            {
                return true;
            }
            return false;
        }
            private void timer1_Tick(object sender, EventArgs e)
        {
            for (int j = 0; j < BallList.Count; j++)
            {
                for (int i = j+1; i < BallList.Count; i++)
                {
                    if (!BallList[i].cooldown)
                    {
                        if (j != i && Colide(BallList[i], BallList[j]))
                        {
                            
                            
                               List<int> VList = Swapv((int)BallList[j].vx, (int)BallList[j].vy, (int)BallList[i].vx, (int)BallList[i].vy);


                                BallList[i].ball_hit(VList[0], VList[1]);
                                BallList[j].ball_hit(VList[2], VList[3]);
                                BallList[j].cooldown = true;
                            
                          

                        }
                        else
                        {
                            BallList[j].cooldown = false;
                        }

                    }

                }
            }
   
            foreach (var ball in BallList)
            {
                foreach (var hole in HoleList)
                {
                    if (ColideHole(ball, hole))
                    {
                        BallList.Remove(ball);
                        return;
                    }
                }
                
                ball.ball_bounce_check();
                ball.roll();
            }
            pictureBox1.Invalidate();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;
            foreach(var ball in BallList)
            {
                ball.Draw(g);
            }
            
            foreach(var hole in HoleList)
            {
                hole.Draw(g);
            }
        


        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int clicky = e.Y;
            int clickx = e.X;
            foreach (var ball in BallList)
            {
                if (!ball.ball_click)
                {
                    if (clickx >= ball.x - ball.r & clickx <= ball.x + ball.r & clicky <= ball.y + ball.r & clicky >= ball.y - ball.r)
                    {
                        ball.ball_click = true;

                    }
                }
                else
                {
                    ball.ball_click_two(clickx, clicky);
                }
            }

            


        }
    }
}
